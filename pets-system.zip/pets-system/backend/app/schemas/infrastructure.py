import uuid
from datetime import date, datetime
from decimal import Decimal
from typing import Optional
from pydantic import BaseModel, Field, ConfigDict


class InfraBaselineCreate(BaseModel):
    period_label: str = Field(..., max_length=20)
    period_start: date
    period_end: date
    target_uptime_pct: Decimal = Decimal("99.9")
    target_tech_readiness_score: Decimal = Field(..., ge=0, le=100)
    target_digital_transformation_pct: Decimal = Field(..., ge=0, le=100)


class InfraBaselineOut(InfraBaselineCreate):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    project_id: uuid.UUID
    created_at: datetime


class InfraActualCreate(BaseModel):
    actual_uptime_pct: Decimal = Field(..., ge=0, le=100)
    actual_tech_readiness_score: Decimal = Field(..., ge=0, le=100)
    actual_digital_transformation_pct: Decimal = Field(..., ge=0, le=100)
    incidents_count: int = 0
    recorded_date: Optional[date] = None
    notes: Optional[str] = None


class InfraActualOut(InfraActualCreate):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    baseline_id: uuid.UUID
    created_at: datetime


class InfraVarianceOut(BaseModel):
    project_id: uuid.UUID
    baseline_id: uuid.UUID
    period_label: str
    target_uptime_pct: Decimal
    actual_uptime_pct: Decimal
    uptime_variance_pct: Decimal
    target_tech_readiness_score: Decimal
    actual_tech_readiness_score: Decimal
    tech_readiness_variance: Decimal
    target_digital_transformation_pct: Decimal
    actual_digital_transformation_pct: Decimal
    digital_transformation_variance_pct: Decimal
    incidents_count: int
    status: str
