import uuid
from datetime import date, datetime
from typing import Optional
from pydantic import BaseModel, Field, ConfigDict


class ProjectBase(BaseModel):
    code: str = Field(..., max_length=30, examples=["PRJ-2026-014"])
    name: str = Field(..., max_length=200)
    description: Optional[str] = None
    manager_id: Optional[uuid.UUID] = None
    sponsor_id: Optional[uuid.UUID] = None
    start_date: date
    planned_end_date: date
    currency: str = Field(default="EGP", max_length=3)


class ProjectCreate(ProjectBase):
    pass


class ProjectUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[str] = None
    manager_id: Optional[uuid.UUID] = None
    planned_end_date: Optional[date] = None
    actual_end_date: Optional[date] = None


class ProjectOut(ProjectBase):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    status: str
    actual_end_date: Optional[date] = None
    created_at: datetime
    updated_at: datetime
