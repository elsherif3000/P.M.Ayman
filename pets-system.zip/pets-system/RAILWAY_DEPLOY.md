# نشر PETS على Railway

3 خدمات في نفس المشروع: **Postgres** (جاهزة من Railway) + **Backend** (FastAPI) + **Frontend** (React).

## الطريقة أ) عن طريق الموقع (أسهل، بدون CLI)

### 1. إنشاء المشروع + قاعدة البيانات
1. سجّل دخول على [railway.app](https://railway.app) → **New Project**
2. اختار **Provision PostgreSQL** — هيديك قاعدة بيانات جاهزة فورًا
3. افتح تبويب **Variables** بتاع خدمة Postgres وانسخ قيمة `DATABASE_URL`

### 2. تطبيق الـ schema على القاعدة
من جهازك (لو عندك `psql`):
```bash
psql "<DATABASE_URL بتاعت Railway>" -f database/schema.sql
```
لو مفيش `psql` عندك، افتح تبويب **Data** في خدمة Postgres على Railway وارفع محتوى `database/schema.sql` من الـ Query editor مباشرة.

### 3. نشر الباك إند (FastAPI)
1. في نفس المشروع: **New** → **GitHub Repo** (لو رفعت الكود على GitHub) أو **Empty Service** ثم اربطه بمجلد `backend/`
2. Railway هيلاقي `backend/railway.json` ويستخدم الـ Dockerfile تلقائيًا
3. من تبويب **Variables** بتاع خدمة الباك إند، ضيف:
   - `DATABASE_URL` = نفس قيمة قاعدة البيانات، لكن غيّر البادئة من `postgresql://` إلى `postgresql+asyncpg://`
   - `ALLOWED_ORIGINS` = هتحطها بعد ما تاخد رابط الفرونت إند في الخطوة الجاية (اتركها فاضية دلوقتي أو حط `*` مؤقتًا)
4. من تبويب **Settings** → **Networking** → **Generate Domain** — هيديك رابط زي `pets-backend.up.railway.app`

### 4. نشر الفرونت إند (React)
1. **New** → اربطه بمجلد `frontend/`
2. Railway هيستخدم `frontend/railway.json` (Nixpacks + `npm run build` + `serve`)
3. من **Variables**، ضيف:
   - `VITE_API_URL` = `https://pets-backend.up.railway.app/api/v1` (رابط الباك إند من الخطوة اللي فاتت + `/api/v1`)
4. **Generate Domain** — هيديك رابط زي `pets-frontend.up.railway.app` ← **ده اللينك اللي تفتحه في المتصفح**
5. ارجع لخدمة الباك إند وحدّث `ALLOWED_ORIGINS` = `https://pets-frontend.up.railway.app`، وأعد التشغيل (Redeploy)

### ✅ خلاص
افتح `https://pets-frontend.up.railway.app` — التطبيق شغال بلينك عام تقدر تبعته لأي حد.

---

## الطريقة ب) عن طريق Railway CLI (أسرع لو الكود عندك محلي)

```bash
npm install -g @railway/cli
railway login

cd pets-system
railway init                     # ينشئ مشروع جديد

railway add --plugin postgresql  # يضيف قاعدة بيانات

# طبّق الـ schema
railway run psql $DATABASE_URL -f database/schema.sql

# انشر الباك إند
cd backend
railway up
railway domain                   # ياخدلك رابط الباك إند

# ارجع وانشر الفرونت إند
cd ../frontend
railway variables set VITE_API_URL=https://<رابط-الباك-إند>/api/v1
railway up
railway domain                   # ده رابط التطبيق النهائي
```

## ملاحظات
- الخطة المجانية (Trial) بتدّيك رصيد تجريبي كفاية للتجربة والعرض، وبعدها محتاج خطة مدفوعة صغيرة للاستمرار.
- لو غيّرت `database/schema.sql` بعدين، لازم تطبّق التعديلات يدويًا (مفيش migrations تلقائية في النسخة دي — لو حابب أضيف Alembic للـ migrations قولّي).
