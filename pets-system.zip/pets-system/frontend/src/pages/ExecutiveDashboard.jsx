import { useEffect, useMemo, useState } from "react";
import { api } from "../api/client";
import KPICard from "../components/KPICard";
import StatusBadge from "../components/StatusBadge";
import DimensionPulse from "../components/DimensionPulse";

// Demo data so this page renders even without a live backend connection —
// shaped exactly like GET /api/v1/dashboard/executive.
const DEMO_PROJECTS = [
  { project_id: "1", code: "PRJ-2026-014", name: "Core Banking Migration", status: "active",
    budget_variance_pct: 4.2, task_completion_rate_pct: 92, spi: 1.02, scope_progress_pct: 88,
    dimension_status: { financial: "on_track", hr: "on_track", infrastructure: "on_track", scope: "on_track", overall: "on_track" } },
  { project_id: "2", code: "PRJ-2026-021", name: "Red Sea Logistics Hub", status: "active",
    budget_variance_pct: 14.8, task_completion_rate_pct: 71, spi: 0.86, scope_progress_pct: 63,
    dimension_status: { financial: "warning", hr: "warning", infrastructure: "on_track", scope: "warning", overall: "warning" } },
  { project_id: "3", code: "PRJ-2026-009", name: "National Grid Digitization", status: "active",
    budget_variance_pct: 27.5, task_completion_rate_pct: 48, spi: 0.71, scope_progress_pct: 40,
    dimension_status: { financial: "critical", hr: "critical", infrastructure: "warning", scope: "critical", overall: "critical" } },
  { project_id: "4", code: "PRJ-2026-033", name: "Public Health Records API", status: "active",
    budget_variance_pct: -2.1, task_completion_rate_pct: 97, spi: 1.05, scope_progress_pct: 95,
    dimension_status: { financial: "on_track", hr: "on_track", infrastructure: "on_track", scope: "on_track", overall: "on_track" } },
  { project_id: "5", code: "PRJ-2026-027", name: "Smart Ports Sensor Network", status: "active",
    budget_variance_pct: 9.6, task_completion_rate_pct: 80, spi: 0.94, scope_progress_pct: 77,
    dimension_status: { financial: "warning", hr: "on_track", infrastructure: "warning", scope: "on_track", overall: "warning" } },
];

const RANK = { on_track: 0, warning: 1, critical: 2 };

export default function ExecutiveDashboard() {
  const [projects, setProjects] = useState(DEMO_PROJECTS);
  const [filter, setFilter] = useState("all");
  const [loading, setLoading] = useState(true);
  const [isLive, setIsLive] = useState(false);

  useEffect(() => {
    api
      .getExecutiveDashboard("active")
      .then((data) => {
        if (data?.length) {
          setProjects(data);
          setIsLive(true);
        }
      })
      .catch(() => {
        // No backend reachable in this preview — keep demo data.
      })
      .finally(() => setLoading(false));
  }, []);

  const visible = useMemo(
    () => (filter === "all" ? projects : projects.filter((p) => p.dimension_status.overall === filter)),
    [projects, filter]
  );

  const fleetStats = useMemo(() => {
    const dims = ["financial", "hr", "infrastructure", "scope"];
    const stats = {};
    for (const dim of dims) {
      stats[dim] = { on_track: 0, warning: 0, critical: 0 };
      for (const p of projects) stats[dim][p.dimension_status[dim]]++;
    }
    const avgBudgetVar = (
      projects.reduce((sum, p) => sum + (Number(p.budget_variance_pct) || 0), 0) / (projects.length || 1)
    ).toFixed(1);
    const avgSpi = (
      projects.reduce((sum, p) => sum + (Number(p.spi) || 0), 0) / (projects.length || 1)
    ).toFixed(2);
    return { stats, avgBudgetVar, avgSpi };
  }, [projects]);

  const filterTabs = [
    { key: "all", label: "All Projects" },
    { key: "on_track", label: "On Track" },
    { key: "warning", label: "Warning" },
    { key: "critical", label: "Critical" },
  ];

  return (
    <div className="min-h-screen bg-ink-950 font-body text-ivory">
      <div className="mx-auto max-w-7xl px-6 py-8">
        {/* Header */}
        <header className="flex flex-col gap-1 mb-8">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-[11px] font-mono uppercase tracking-[0.2em] text-brand-500">PETS · Executive View</p>
              <h1 className="font-display text-2xl md:text-3xl text-ivory mt-1">Project Portfolio Health</h1>
            </div>
            <div className="flex items-center gap-2 text-[11px] font-mono text-mist">
              <span className={`h-1.5 w-1.5 rounded-full ${isLive ? "bg-status-onTrack" : "bg-mist"}`} />
              {loading ? "Connecting…" : isLive ? "Live data" : "Preview data"}
            </div>
          </div>
          <p className="text-sm text-mist max-w-2xl">
            Financial, HR, Infrastructure & Technology, and Scope — four dimensions,
            one variance model, rolled up per project.
          </p>
        </header>

        {/* KPI Cards */}
        <section className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <KPICard
            eyebrow="Financial"
            label="Avg. Budget Variance"
            value={`${fleetStats.avgBudgetVar > 0 ? "+" : ""}${fleetStats.avgBudgetVar}`}
            unit="%"
            counts={fleetStats.stats.financial}
          />
          <KPICard
            eyebrow="Human Resources"
            label="Task Completion Health"
            value={projects.length}
            unit="projects"
            counts={fleetStats.stats.hr}
          />
          <KPICard
            eyebrow="Infrastructure & Tech"
            label="Readiness & Uptime"
            value={projects.length}
            unit="projects"
            counts={fleetStats.stats.infrastructure}
          />
          <KPICard
            eyebrow="Scope & Deliverables"
            label="Avg. Schedule Perf. Index"
            value={fleetStats.avgSpi}
            unit="SPI"
            counts={fleetStats.stats.scope}
          />
        </section>

        {/* Filter tabs */}
        <div className="flex items-center gap-1 mb-4 border-b border-ink-700">
          {filterTabs.map((tab) => (
            <button
              key={tab.key}
              onClick={() => setFilter(tab.key)}
              className={`px-4 py-2.5 text-sm font-medium border-b-2 transition-colors -mb-px
                ${filter === tab.key
                  ? "border-brand-500 text-ivory"
                  : "border-transparent text-mist hover:text-ivory"}`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Projects table */}
        <div className="rounded-xl border border-ink-700 overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-ink-900 text-left text-[11px] font-mono uppercase tracking-wider text-mist">
                <th className="px-5 py-3 font-medium">Project</th>
                <th className="px-5 py-3 font-medium">Dimensions</th>
                <th className="px-5 py-3 font-medium text-right">Budget Var.</th>
                <th className="px-5 py-3 font-medium text-right">Task Completion</th>
                <th className="px-5 py-3 font-medium text-right">SPI</th>
                <th className="px-5 py-3 font-medium text-right">Scope Progress</th>
                <th className="px-5 py-3 font-medium text-right">Status</th>
              </tr>
            </thead>
            <tbody>
              {visible.map((p, i) => (
                <tr
                  key={p.project_id}
                  className={`border-t border-ink-700 hover:bg-ink-800/60 transition-colors ${i % 2 ? "bg-ink-900/40" : ""}`}
                >
                  <td className="px-5 py-4">
                    <p className="text-ivory font-medium">{p.name}</p>
                    <p className="font-mono text-[11px] text-mist">{p.code}</p>
                  </td>
                  <td className="px-5 py-4">
                    <DimensionPulse dimensionStatus={p.dimension_status} />
                  </td>
                  <td className={`px-5 py-4 text-right font-mono tabular-nums ${Number(p.budget_variance_pct) > 0 ? "text-status-warning" : "text-status-onTrack"}`}>
                    {Number(p.budget_variance_pct) > 0 ? "+" : ""}{Number(p.budget_variance_pct).toFixed(1)}%
                  </td>
                  <td className="px-5 py-4 text-right font-mono tabular-nums text-ivory">
                    {Number(p.task_completion_rate_pct).toFixed(0)}%
                  </td>
                  <td className="px-5 py-4 text-right font-mono tabular-nums text-ivory">
                    {Number(p.spi).toFixed(2)}
                  </td>
                  <td className="px-5 py-4 text-right font-mono tabular-nums text-ivory">
                    {Number(p.scope_progress_pct).toFixed(0)}%
                  </td>
                  <td className="px-5 py-4 text-right">
                    <StatusBadge status={p.dimension_status.overall} />
                  </td>
                </tr>
              ))}
              {visible.length === 0 && (
                <tr>
                  <td colSpan={7} className="px-5 py-10 text-center text-mist text-sm">
                    No projects match this filter.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        <p className="mt-4 text-[11px] font-mono text-mist">
          Status thresholds are configurable per metric (kpi_thresholds table) — shown here with default values.
        </p>
      </div>
    </div>
  );
}
