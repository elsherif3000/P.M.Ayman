import uuid
from typing import List
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select, text
from sqlalchemy.ext.asyncio import AsyncSession

from ..database import get_db
from ..models import InfraBaseline, InfraActual, Project
from ..schemas.infrastructure import (
    InfraBaselineCreate, InfraBaselineOut, InfraActualCreate, InfraActualOut, InfraVarianceOut,
)
from ..status_utils import resolve_status

router = APIRouter(prefix="/api/v1/projects/{project_id}/infrastructure", tags=["Infrastructure Dimension"])


async def _get_project_or_404(db: AsyncSession, project_id: uuid.UUID) -> Project:
    project = await db.get(Project, project_id)
    if not project:
        raise HTTPException(404, "Project not found")
    return project


@router.post("/baselines", response_model=InfraBaselineOut, status_code=201)
async def create_infra_baseline(project_id: uuid.UUID, payload: InfraBaselineCreate, db: AsyncSession = Depends(get_db)):
    await _get_project_or_404(db, project_id)
    baseline = InfraBaseline(project_id=project_id, **payload.model_dump())
    db.add(baseline)
    await db.commit()
    await db.refresh(baseline)
    return baseline


@router.get("/baselines", response_model=List[InfraBaselineOut])
async def list_infra_baselines(project_id: uuid.UUID, db: AsyncSession = Depends(get_db)):
    await _get_project_or_404(db, project_id)
    result = await db.execute(select(InfraBaseline).where(InfraBaseline.project_id == project_id))
    return result.scalars().all()


@router.post("/baselines/{baseline_id}/actuals", response_model=InfraActualOut, status_code=201)
async def record_infra_actual(
    project_id: uuid.UUID, baseline_id: uuid.UUID, payload: InfraActualCreate, db: AsyncSession = Depends(get_db)
):
    baseline = await db.get(InfraBaseline, baseline_id)
    if not baseline or baseline.project_id != project_id:
        raise HTTPException(404, "Baseline not found for this project")
    actual = InfraActual(baseline_id=baseline_id, **payload.model_dump(exclude_none=True))
    db.add(actual)
    await db.commit()
    await db.refresh(actual)
    return actual


@router.get("/variance", response_model=List[InfraVarianceOut])
async def get_infra_variance(project_id: uuid.UUID, db: AsyncSession = Depends(get_db)):
    await _get_project_or_404(db, project_id)
    rows = (await db.execute(
        text("SELECT * FROM v_infra_variance WHERE project_id = :pid ORDER BY recorded_date"),
        {"pid": str(project_id)},
    )).mappings().all()

    out = []
    for row in rows:
        data = dict(row)
        data["status"] = await resolve_status(db, "uptime_variance_pct", data.get("uptime_variance_pct"))
        out.append(data)
    return out
