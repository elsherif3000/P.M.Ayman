# PETS — Project Evaluation and Tracking System

A web application that evaluates and tracks projects across **4 core dimensions**:

| Dimension | Key metrics |
|---|---|
| **Financial** | Budget variance %, cash flow (in/out), ROI variance |
| **Human Resources** | Task completion rate, resource utilization % |
| **Infrastructure & Technology** | Uptime variance, tech readiness score, digital transformation compliance |
| **Scope & Deliverables** | Scope progress %, quality index, Schedule Performance Index (SPI = EV / PV) |

Every dimension follows the same **Baseline → Actual → Variance** pattern: a plan is
entered once per reporting period (baseline), progress updates are recorded against
it (actuals), and variance is **always computed server-side** (SQL views in
Postgres, never trusted from the client) — so numbers can never drift out of sync.

## 1. Directory structure

```
pets-system/
├── database/
│   └── schema.sql              # PostgreSQL DDL: tables, views, thresholds, seed data
│
├── backend/                    # FastAPI (Python 3.11+)
│   ├── requirements.txt
│   └── app/
│       ├── main.py             # App entrypoint, router wiring, CORS
│       ├── database.py         # Async SQLAlchemy engine/session
│       ├── models.py           # ORM models mirroring schema.sql
│       ├── status_utils.py     # Variance → On Track/Warning/Critical logic
│       ├── schemas/            # Pydantic request/response models
│       │   ├── project.py
│       │   ├── financial.py
│       │   ├── hr.py
│       │   ├── infrastructure.py
│       │   └── scope.py
│       └── routers/            # One router per resource
│           ├── projects.py
│           ├── financial.py
│           ├── hr.py
│           ├── infrastructure.py
│           ├── scope.py
│           └── dashboard.py    # Executive Dashboard aggregate endpoint
│
└── frontend/                   # React 18 + Tailwind CSS (Vite)
    ├── tailwind.config.js      # Design tokens (palette, type scale)
    └── src/
        ├── App.jsx
        ├── index.css
        ├── api/client.js       # Fetch wrapper for the FastAPI backend
        ├── components/
        │   ├── KPICard.jsx
        │   ├── StatusBadge.jsx     # On Track / Warning / Critical pill
        │   └── DimensionPulse.jsx  # 4-segment per-dimension health strip
        └── pages/
            └── ExecutiveDashboard.jsx
```

## 2. Database (PostgreSQL)

See `database/schema.sql`. Highlights:

- `projects`, `users` — core entities.
- `financial_baselines` / `financial_actuals`, `hr_baselines` / `hr_actuals`,
  `infra_baselines` / `infra_actuals`, `scope_baselines` / `scope_actuals` —
  one baseline+actual pair per dimension, one row per reporting period.
- `kpi_thresholds` — warning/critical cutoffs are **data, not code**, so
  finance/PMO can retune "what counts as a warning" without a deploy.
- `v_financial_variance`, `v_hr_variance`, `v_infra_variance`, `v_scope_variance` —
  views that compute every % variance and the SPI ratio directly in SQL.
- `v_project_dashboard` — one row per project with the latest period from
  all 4 views joined together; this is what powers the Executive Dashboard.

Apply it with:
```bash
createdb pets_db
psql -d pets_db -f database/schema.sql
```

## 3. Backend (FastAPI)

```bash
cd backend
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
export DATABASE_URL=postgresql+asyncpg://pets_user:pets_password@localhost:5432/pets_db
uvicorn app.main:app --reload
```

### Core endpoints

| Method | Path | Purpose |
|---|---|---|
| `POST` | `/api/v1/projects` | Create a project |
| `GET` | `/api/v1/projects` | List projects (filter by status/manager) |
| `POST` | `/api/v1/projects/{id}/financial/baselines` | Enter a financial plan for a period |
| `POST` | `/api/v1/projects/{id}/financial/baselines/{bid}/actuals` | Record actual cost/cash/ROI |
| `GET` | `/api/v1/projects/{id}/financial/variance` | **Auto-computed** budget/ROI variance + status |
| `POST` | `/api/v1/projects/{id}/hr/baselines` \| `.../actuals` | Same pattern for HR |
| `POST` | `/api/v1/projects/{id}/infrastructure/baselines` \| `.../actuals` | Same pattern for Infra |
| `POST` | `/api/v1/projects/{id}/scope/baselines` \| `.../actuals` | Same pattern for Scope/SPI |
| `GET` | `/api/v1/dashboard/executive` | All projects, all 4 dimensions, rolled-up status |

Interactive docs are auto-generated at `/docs` once the server is running.

## 4. Frontend (React + Tailwind)

```bash
cd frontend
npm install
npm run dev
```

The **Executive Dashboard** (`src/pages/ExecutiveDashboard.jsx`) is the main screen:
KPI cards summarizing each dimension fleet-wide, a filterable project table, and a
per-project "dimension pulse" strip (4 colored segments — one per dimension) so
health is scannable at a glance. It calls `GET /dashboard/executive` and falls back
to bundled demo data if the API isn't reachable, so it always renders something
useful in preview.

## 5. Status logic (On Track / Warning / Critical)

`backend/app/status_utils.py` is the single place a variance number becomes a
status label. It reads `kpi_thresholds` per metric and compares the *distance
from the ideal* (0 variance, or SPI ≥ 1.0) against warning/critical cutoffs —
so a metric where "higher is better" (SPI, ROI) and one where "lower is better"
(budget overrun) are both handled correctly by the same function.
