/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: {
        // Command-center palette: desaturated navy/slate ground so the
        // semantic status colors (on_track / warning / critical) are the
        // only saturated color in the UI and therefore read instantly.
        ink: {
          950: "#0B1220",
          900: "#101A2E",
          800: "#16233C",
          700: "#1E2E4A",
          600: "#2C3F60",
        },
        ivory: "#EDEFF4",
        mist: "#8C96AC",
        brand: {
          500: "#4FD1C5", // muted teal — brand accent, used sparingly
          600: "#38B2AC",
        },
        status: {
          onTrack: "#3DD68C",
          warning: "#F5B94D",
          critical: "#F0625B",
        },
      },
      fontFamily: {
        display: ["Space Grotesk", "sans-serif"],
        body: ["IBM Plex Sans", "sans-serif"],
        mono: ["IBM Plex Mono", "monospace"],
      },
    },
  },
  plugins: [],
};
