import uuid
from typing import List
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select, text
from sqlalchemy.ext.asyncio import AsyncSession

from ..database import get_db
from ..models import ScopeBaseline, ScopeActual, Project
from ..schemas.scope import (
    ScopeBaselineCreate, ScopeBaselineOut, ScopeActualCreate, ScopeActualOut, ScopeVarianceOut,
)
from ..status_utils import resolve_status

router = APIRouter(prefix="/api/v1/projects/{project_id}/scope", tags=["Scope Dimension"])


async def _get_project_or_404(db: AsyncSession, project_id: uuid.UUID) -> Project:
    project = await db.get(Project, project_id)
    if not project:
        raise HTTPException(404, "Project not found")
    return project


@router.post("/baselines", response_model=ScopeBaselineOut, status_code=201)
async def create_scope_baseline(project_id: uuid.UUID, payload: ScopeBaselineCreate, db: AsyncSession = Depends(get_db)):
    await _get_project_or_404(db, project_id)
    baseline = ScopeBaseline(project_id=project_id, **payload.model_dump())
    db.add(baseline)
    await db.commit()
    await db.refresh(baseline)
    return baseline


@router.get("/baselines", response_model=List[ScopeBaselineOut])
async def list_scope_baselines(project_id: uuid.UUID, db: AsyncSession = Depends(get_db)):
    await _get_project_or_404(db, project_id)
    result = await db.execute(select(ScopeBaseline).where(ScopeBaseline.project_id == project_id))
    return result.scalars().all()


@router.post("/baselines/{baseline_id}/actuals", response_model=ScopeActualOut, status_code=201)
async def record_scope_actual(
    project_id: uuid.UUID, baseline_id: uuid.UUID, payload: ScopeActualCreate, db: AsyncSession = Depends(get_db)
):
    baseline = await db.get(ScopeBaseline, baseline_id)
    if not baseline or baseline.project_id != project_id:
        raise HTTPException(404, "Baseline not found for this project")
    actual = ScopeActual(baseline_id=baseline_id, **payload.model_dump(exclude_none=True))
    db.add(actual)
    await db.commit()
    await db.refresh(actual)
    return actual


@router.get("/variance", response_model=List[ScopeVarianceOut])
async def get_scope_variance(project_id: uuid.UUID, db: AsyncSession = Depends(get_db)):
    """SPI = EV / PV, computed in the v_scope_variance SQL view."""
    await _get_project_or_404(db, project_id)
    rows = (await db.execute(
        text("SELECT * FROM v_scope_variance WHERE project_id = :pid ORDER BY recorded_date"),
        {"pid": str(project_id)},
    )).mappings().all()

    out = []
    for row in rows:
        data = dict(row)
        data["status"] = await resolve_status(db, "spi", data.get("spi"))
        out.append(data)
    return out
