const CONFIG = {
  on_track: { label: "On Track", dot: "bg-status-onTrack", text: "text-status-onTrack", ring: "ring-status-onTrack/30" },
  warning: { label: "Warning", dot: "bg-status-warning", text: "text-status-warning", ring: "ring-status-warning/30" },
  critical: { label: "Critical", dot: "bg-status-critical", text: "text-status-critical", ring: "ring-status-critical/30" },
};

/**
 * Semantic status pill. Color is the ONLY saturated color allowed to appear
 * on the dashboard, by design — so a glance at the page tells you where
 * attention is needed.
 */
export default function StatusBadge({ status = "on_track", size = "md" }) {
  const cfg = CONFIG[status] ?? CONFIG.on_track;
  const pad = size === "sm" ? "px-2 py-0.5 text-[11px]" : "px-2.5 py-1 text-xs";

  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full ${pad} font-medium font-mono uppercase tracking-wide
                  bg-ink-800 ring-1 ${cfg.ring} ${cfg.text}`}
    >
      <span className={`h-1.5 w-1.5 rounded-full ${cfg.dot}`} />
      {cfg.label}
    </span>
  );
}
