from typing import List, Optional
from fastapi import APIRouter, Depends, Query
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession
from pydantic import BaseModel
from decimal import Decimal

from ..database import get_db
from ..status_utils import resolve_status

router = APIRouter(prefix="/api/v1/dashboard", tags=["Executive Dashboard"])

_RANK = {"on_track": 0, "warning": 1, "critical": 2}


class DimensionStatus(BaseModel):
    financial: str
    hr: str
    infrastructure: str
    scope: str
    overall: str


class DashboardProject(BaseModel):
    project_id: str
    code: str
    name: str
    status: str
    budget_variance_pct: Optional[Decimal] = None
    task_completion_rate_pct: Optional[Decimal] = None
    resource_utilization_pct: Optional[Decimal] = None
    uptime_variance_pct: Optional[Decimal] = None
    digital_transformation_variance_pct: Optional[Decimal] = None
    spi: Optional[Decimal] = None
    scope_progress_pct: Optional[Decimal] = None
    dimension_status: DimensionStatus


@router.get("/executive", response_model=List[DashboardProject])
async def get_executive_dashboard(
    status: Optional[str] = Query(None, description="Filter by project status (e.g. active)"),
    db: AsyncSession = Depends(get_db),
):
    """
    Single call that powers the Executive Dashboard: latest-period variance
    across all 4 dimensions for every project, each with a rolled-up
    On Track / Warning / Critical indicator.
    """
    sql = "SELECT * FROM v_project_dashboard"
    params = {}
    if status:
        sql += " WHERE status = :status"
        params["status"] = status

    rows = (await db.execute(text(sql), params)).mappings().all()

    result = []
    for row in rows:
        fin_status = await resolve_status(db, "budget_variance_pct", row.get("budget_variance_pct"))
        completion = row.get("task_completion_rate_pct")
        hr_status = await resolve_status(
            db, "task_completion_rate_pct",
            None if completion is None else completion - 100
        )
        infra_status = await resolve_status(db, "uptime_variance_pct", row.get("uptime_variance_pct"))
        scope_status = await resolve_status(db, "spi", row.get("spi"))
        overall = max([fin_status, hr_status, infra_status, scope_status], key=lambda s: _RANK[s])

        result.append(DashboardProject(
            project_id=str(row["project_id"]),
            code=row["code"],
            name=row["name"],
            status=row["status"],
            budget_variance_pct=row.get("budget_variance_pct"),
            task_completion_rate_pct=row.get("task_completion_rate_pct"),
            resource_utilization_pct=row.get("resource_utilization_pct"),
            uptime_variance_pct=row.get("uptime_variance_pct"),
            digital_transformation_variance_pct=row.get("digital_transformation_variance_pct"),
            spi=row.get("spi"),
            scope_progress_pct=row.get("scope_progress_pct"),
            dimension_status=DimensionStatus(
                financial=fin_status, hr=hr_status, infrastructure=infra_status,
                scope=scope_status, overall=overall,
            ),
        ))
    return result
