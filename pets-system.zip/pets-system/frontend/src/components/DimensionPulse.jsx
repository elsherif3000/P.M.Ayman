const COLOR = {
  on_track: "bg-status-onTrack",
  warning: "bg-status-warning",
  critical: "bg-status-critical",
};

const DIMENSIONS = [
  { key: "financial", label: "FIN" },
  { key: "hr", label: "HR" },
  { key: "infrastructure", label: "TECH" },
  { key: "scope", label: "SCOPE" },
];

/**
 * The dashboard's signature element: a 4-segment "pulse strip", one segment
 * per evaluation dimension, colored by that dimension's own status. It's
 * the visual signature of the whole system — a single glyph that always
 * encodes exactly the 4 things the app was built to track.
 */
export default function DimensionPulse({ dimensionStatus }) {
  return (
    <div className="flex items-stretch gap-0.5 h-8 w-full max-w-[180px]">
      {DIMENSIONS.map((d) => (
        <div key={d.key} className="flex-1 group relative">
          <div className={`h-full w-full rounded-sm ${COLOR[dimensionStatus[d.key]] ?? "bg-ink-700"}`} />
          <span className="absolute -bottom-4 left-1/2 -translate-x-1/2 text-[9px] font-mono text-mist opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">
            {d.label}
          </span>
        </div>
      ))}
    </div>
  );
}
