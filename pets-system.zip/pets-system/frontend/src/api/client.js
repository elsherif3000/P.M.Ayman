const BASE_URL = import.meta.env.VITE_API_URL || "http://localhost:8000/api/v1";

async function request(path, options = {}) {
  const res = await fetch(`${BASE_URL}${path}`, {
    headers: { "Content-Type": "application/json" },
    ...options,
  });
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body.detail || `Request failed: ${res.status}`);
  }
  return res.status === 204 ? null : res.json();
}

export const api = {
  getExecutiveDashboard: (status) =>
    request(`/dashboard/executive${status ? `?status=${status}` : ""}`),
  listProjects: () => request("/projects"),
  createProject: (payload) =>
    request("/projects", { method: "POST", body: JSON.stringify(payload) }),

  createFinancialBaseline: (projectId, payload) =>
    request(`/projects/${projectId}/financial/baselines`, {
      method: "POST", body: JSON.stringify(payload),
    }),
  recordFinancialActual: (projectId, baselineId, payload) =>
    request(`/projects/${projectId}/financial/baselines/${baselineId}/actuals`, {
      method: "POST", body: JSON.stringify(payload),
    }),
  getFinancialVariance: (projectId) =>
    request(`/projects/${projectId}/financial/variance`),

  getHrVariance: (projectId) => request(`/projects/${projectId}/hr/variance`),
  getInfraVariance: (projectId) => request(`/projects/${projectId}/infrastructure/variance`),
  getScopeVariance: (projectId) => request(`/projects/${projectId}/scope/variance`),
};
