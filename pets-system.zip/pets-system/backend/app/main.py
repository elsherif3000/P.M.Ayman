import os
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from .routers import projects, financial, hr, infrastructure, scope, dashboard

app = FastAPI(
    title="PETS — Project Evaluation & Tracking System API",
    description="Tracks projects across Financial, HR, Infrastructure & Technology, "
                "and Scope & Deliverables dimensions, with server-computed variance.",
    version="1.0.0",
)

# Comma-separated list, e.g. "https://pets-frontend.up.railway.app,http://localhost:5173"
_origins_env = os.getenv("ALLOWED_ORIGINS", "http://localhost:5173,http://localhost:3000")
allowed_origins = [o.strip() for o in _origins_env.split(",") if o.strip()]

app.add_middleware(
    CORSMiddleware,
    allow_origins=allowed_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(projects.router)
app.include_router(financial.router)
app.include_router(hr.router)
app.include_router(infrastructure.router)
app.include_router(scope.router)
app.include_router(dashboard.router)


@app.get("/api/v1/health", tags=["System"])
async def health_check():
    return {"status": "ok"}
