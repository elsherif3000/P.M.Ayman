import uuid
from typing import List
from decimal import Decimal
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select, text
from sqlalchemy.ext.asyncio import AsyncSession

from ..database import get_db
from ..models import FinancialBaseline, FinancialActual, Project
from ..schemas.financial import (
    FinancialBaselineCreate, FinancialBaselineOut,
    FinancialActualCreate, FinancialActualOut, FinancialVarianceOut,
)
from ..status_utils import resolve_status

router = APIRouter(prefix="/api/v1/projects/{project_id}/financial", tags=["Financial Dimension"])


async def _get_project_or_404(db: AsyncSession, project_id: uuid.UUID) -> Project:
    project = await db.get(Project, project_id)
    if not project:
        raise HTTPException(404, "Project not found")
    return project


# ---------------------------------------------------------------------------
# BASELINES (the plan)
# ---------------------------------------------------------------------------
@router.post("/baselines", response_model=FinancialBaselineOut, status_code=201)
async def create_financial_baseline(
    project_id: uuid.UUID, payload: FinancialBaselineCreate, db: AsyncSession = Depends(get_db)
):
    await _get_project_or_404(db, project_id)
    exists = await db.execute(
        select(FinancialBaseline).where(
            FinancialBaseline.project_id == project_id,
            FinancialBaseline.period_label == payload.period_label,
        )
    )
    if exists.scalar_one_or_none():
        raise HTTPException(409, f"Baseline for period '{payload.period_label}' already exists")

    baseline = FinancialBaseline(project_id=project_id, **payload.model_dump())
    db.add(baseline)
    await db.commit()
    await db.refresh(baseline)
    return baseline


@router.get("/baselines", response_model=List[FinancialBaselineOut])
async def list_financial_baselines(project_id: uuid.UUID, db: AsyncSession = Depends(get_db)):
    await _get_project_or_404(db, project_id)
    result = await db.execute(
        select(FinancialBaseline)
        .where(FinancialBaseline.project_id == project_id)
        .order_by(FinancialBaseline.period_start)
    )
    return result.scalars().all()


# ---------------------------------------------------------------------------
# ACTUALS (progress updates against a baseline period)
# ---------------------------------------------------------------------------
@router.post("/baselines/{baseline_id}/actuals", response_model=FinancialActualOut, status_code=201)
async def record_financial_actual(
    project_id: uuid.UUID, baseline_id: uuid.UUID,
    payload: FinancialActualCreate, db: AsyncSession = Depends(get_db),
):
    baseline = await db.get(FinancialBaseline, baseline_id)
    if not baseline or baseline.project_id != project_id:
        raise HTTPException(404, "Baseline not found for this project")

    actual = FinancialActual(baseline_id=baseline_id, **payload.model_dump(exclude_none=True))
    db.add(actual)
    await db.commit()
    await db.refresh(actual)
    return actual


# ---------------------------------------------------------------------------
# VARIANCE — always computed server-side, never trusted from the client
# ---------------------------------------------------------------------------
@router.get("/variance", response_model=List[FinancialVarianceOut])
async def get_financial_variance(project_id: uuid.UUID, db: AsyncSession = Depends(get_db)):
    """
    Pulls every period's variance from the v_financial_variance SQL view
    (planned vs actual is computed in the database, not in application code)
    and attaches a status label per period.
    """
    await _get_project_or_404(db, project_id)
    rows = (await db.execute(
        text("SELECT * FROM v_financial_variance WHERE project_id = :pid ORDER BY recorded_date"),
        {"pid": str(project_id)},
    )).mappings().all()

    out = []
    for row in rows:
        data = dict(row)
        data["status"] = await resolve_status(db, "budget_variance_pct", data.get("budget_variance_pct"))
        out.append(data)
    return out
