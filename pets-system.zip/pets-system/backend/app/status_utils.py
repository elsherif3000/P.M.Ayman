"""
Central place where a raw variance number becomes a health_status
(on_track / warning / critical). Thresholds come from the kpi_thresholds
table so business/finance teams can retune them without touching code.

This is the ONLY place status labels are decided — routers and the
dashboard both call resolve_status() so the whole app is consistent.
"""
from decimal import Decimal
from typing import Optional
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from .models import KPIThreshold

# Fallback thresholds used if a metric has no row in kpi_thresholds yet.
DEFAULT_THRESHOLDS = {
    "budget_variance_pct": (10, 20, False),
    "roi_variance_pct": (5, 15, True),
    "task_completion_rate_pct": (10, 20, True),
    "resource_utilization_pct": (15, 30, False),
    "uptime_variance_pct": (1, 3, True),
    "digital_transformation_variance_pct": (10, 25, True),
    "spi": (0.10, 0.20, True),
    "quality_variance": (5, 15, True),
}

_threshold_cache: dict[str, tuple[Decimal, Decimal, bool]] = {}


async def _load_thresholds(db: AsyncSession) -> None:
    if _threshold_cache:
        return
    result = await db.execute(select(KPIThreshold))
    for row in result.scalars().all():
        _threshold_cache[row.metric_key] = (
            row.warning_threshold, row.critical_threshold, row.higher_is_better
        )


async def resolve_status(db: AsyncSession, metric_key: str, value: Optional[Decimal]) -> str:
    """
    Given a metric's current variance value, return 'on_track' | 'warning' | 'critical'.

    Distance from the ideal point is what's compared to thresholds:
      - For "higher_is_better" metrics (SPI, ROI, completion rate...) the ideal
        is >= 0 (or >= 1.0 for SPI); shortfall below that is the distance.
      - For "lower_is_better" metrics (budget overrun, over-utilization) the
        ideal is <= 0; the positive excess is the distance.
    """
    if value is None:
        return "on_track"

    await _load_thresholds(db)
    warning, critical, higher_is_better = _threshold_cache.get(
        metric_key, DEFAULT_THRESHOLDS.get(metric_key, (10, 20, True))
    )
    warning, critical = Decimal(str(warning)), Decimal(str(critical))

    if metric_key == "spi":
        distance = max(Decimal("1.0") - value, Decimal("0"))
    elif higher_is_better:
        distance = max(-value, Decimal("0"))
    else:
        distance = max(value, Decimal("0"))

    if distance >= critical:
        return "critical"
    if distance >= warning:
        return "warning"
    return "on_track"
