import uuid
from datetime import date, datetime
from decimal import Decimal
from typing import Optional
from pydantic import BaseModel, Field, ConfigDict


class HRBaselineCreate(BaseModel):
    period_label: str = Field(..., max_length=20)
    period_start: date
    period_end: date
    planned_tasks_total: int = Field(..., gt=0)
    planned_resource_hours: Decimal = Field(..., gt=0)
    planned_headcount: int = Field(..., gt=0)


class HRBaselineOut(HRBaselineCreate):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    project_id: uuid.UUID
    created_at: datetime


class HRActualCreate(BaseModel):
    tasks_completed: int = Field(..., ge=0)
    resource_hours_used: Decimal = Field(..., ge=0)
    headcount_actual: int = Field(..., ge=0)
    recorded_date: Optional[date] = None
    notes: Optional[str] = None


class HRActualOut(HRActualCreate):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    baseline_id: uuid.UUID
    created_at: datetime


class HRVarianceOut(BaseModel):
    project_id: uuid.UUID
    baseline_id: uuid.UUID
    period_label: str
    planned_tasks_total: int
    tasks_completed: int
    task_completion_rate_pct: Decimal
    planned_resource_hours: Decimal
    resource_hours_used: Decimal
    resource_utilization_pct: Decimal
    planned_headcount: int
    headcount_actual: int
    status: str
