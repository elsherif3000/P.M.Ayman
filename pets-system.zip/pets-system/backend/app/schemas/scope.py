import uuid
from datetime import date, datetime
from decimal import Decimal
from typing import Optional
from pydantic import BaseModel, Field, ConfigDict


class ScopeBaselineCreate(BaseModel):
    period_label: str = Field(..., max_length=20)
    period_start: date
    period_end: date
    planned_deliverables_count: int = Field(..., gt=0)
    planned_value: Decimal = Field(..., gt=0, description="PV — budgeted cost of work scheduled")
    planned_quality_score: Decimal = Decimal("100")


class ScopeBaselineOut(ScopeBaselineCreate):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    project_id: uuid.UUID
    created_at: datetime


class ScopeActualCreate(BaseModel):
    deliverables_completed: int = Field(..., ge=0)
    earned_value: Decimal = Field(..., ge=0, description="EV — budgeted cost of work performed")
    quality_score: Decimal = Field(..., ge=0, le=100)
    recorded_date: Optional[date] = None
    notes: Optional[str] = None


class ScopeActualOut(ScopeActualCreate):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    baseline_id: uuid.UUID
    created_at: datetime


class ScopeVarianceOut(BaseModel):
    project_id: uuid.UUID
    baseline_id: uuid.UUID
    period_label: str
    planned_deliverables_count: int
    deliverables_completed: int
    scope_progress_pct: Decimal
    planned_value: Decimal
    earned_value: Decimal
    spi: Decimal
    schedule_status: str  # ahead_or_on_schedule | behind_schedule
    planned_quality_score: Decimal
    quality_score: Decimal
    quality_variance: Decimal
    status: str
