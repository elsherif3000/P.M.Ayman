-- ============================================================================
-- PETS — Project Evaluation and Tracking System
-- PostgreSQL Schema
-- ============================================================================
-- Design notes:
--   * Each of the 4 dimensions (Financial, HR, Infrastructure, Scope) has its
--     own BASELINE table (the plan, entered once per reporting period) and
--     ACTUALS table (what really happened, entered as updates come in).
--   * Variance is NEVER stored — it is always derived (via VIEWS) from
--     baseline vs actual, so it can never drift out of sync with the source
--     numbers. The API layer exposes these views directly.
--   * kpi_thresholds makes the On Track / Warning / Critical cutoffs
--     configurable per metric instead of hardcoded in application code.
-- ============================================================================

CREATE EXTENSION IF NOT EXISTS pgcrypto; -- gen_random_uuid()

-- ----------------------------------------------------------------------------
-- ENUM TYPES
-- ----------------------------------------------------------------------------
CREATE TYPE user_role AS ENUM ('admin', 'executive', 'project_manager', 'evaluator', 'viewer');
CREATE TYPE project_status AS ENUM ('planning', 'active', 'on_hold', 'completed', 'cancelled');
CREATE TYPE reporting_period_type AS ENUM ('weekly', 'monthly', 'quarterly', 'milestone');
CREATE TYPE health_status AS ENUM ('on_track', 'warning', 'critical');

-- ----------------------------------------------------------------------------
-- USERS
-- ----------------------------------------------------------------------------
CREATE TABLE users (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    full_name       VARCHAR(150)  NOT NULL,
    email           VARCHAR(150)  NOT NULL UNIQUE,
    password_hash   VARCHAR(255)  NOT NULL,
    role            user_role     NOT NULL DEFAULT 'viewer',
    department      VARCHAR(100),
    is_active       BOOLEAN       NOT NULL DEFAULT TRUE,
    created_at      TIMESTAMPTZ   NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ   NOT NULL DEFAULT now()
);

-- ----------------------------------------------------------------------------
-- PROJECTS
-- ----------------------------------------------------------------------------
CREATE TABLE projects (
    id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    code                VARCHAR(30)  NOT NULL UNIQUE,      -- e.g. "PRJ-2026-014"
    name                VARCHAR(200) NOT NULL,
    description         TEXT,
    status              project_status NOT NULL DEFAULT 'planning',
    manager_id          UUID REFERENCES users(id) ON DELETE SET NULL,
    sponsor_id          UUID REFERENCES users(id) ON DELETE SET NULL,
    start_date          DATE NOT NULL,
    planned_end_date    DATE NOT NULL,
    actual_end_date     DATE,
    currency            CHAR(3) NOT NULL DEFAULT 'EGP',
    created_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_projects_status ON projects(status);
CREATE INDEX idx_projects_manager ON projects(manager_id);

-- ----------------------------------------------------------------------------
-- KPI THRESHOLDS (configurable per dimension/metric, not hardcoded)
-- ----------------------------------------------------------------------------
CREATE TABLE kpi_thresholds (
    id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    dimension           VARCHAR(20) NOT NULL CHECK (dimension IN ('financial','hr','infrastructure','scope')),
    metric_key          VARCHAR(50) NOT NULL,              -- e.g. 'budget_variance_pct', 'spi'
    warning_threshold   NUMERIC(6,2) NOT NULL,              -- abs(value) beyond this => warning
    critical_threshold  NUMERIC(6,2) NOT NULL,              -- abs(value) beyond this => critical
    higher_is_better    BOOLEAN NOT NULL DEFAULT TRUE,       -- e.g. SPI: higher is better; cost variance: lower is better
    UNIQUE (dimension, metric_key)
);

-- ============================================================================
-- 1) FINANCIAL DIMENSION
-- ============================================================================
CREATE TABLE financial_baselines (
    id                   UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    project_id           UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    period_type          reporting_period_type NOT NULL DEFAULT 'monthly',
    period_label         VARCHAR(20) NOT NULL,              -- '2026-08', 'Q3-2026', 'Milestone-3'
    period_start         DATE NOT NULL,
    period_end           DATE NOT NULL,
    planned_budget        NUMERIC(16,2) NOT NULL,           -- planned cost for this period
    planned_cash_inflow   NUMERIC(16,2) NOT NULL DEFAULT 0,
    planned_cash_outflow  NUMERIC(16,2) NOT NULL DEFAULT 0,
    expected_roi_pct      NUMERIC(6,2),
    created_by            UUID REFERENCES users(id),
    created_at             TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (project_id, period_label)
);

CREATE TABLE financial_actuals (
    id                   UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    baseline_id          UUID NOT NULL REFERENCES financial_baselines(id) ON DELETE CASCADE,
    actual_cost           NUMERIC(16,2) NOT NULL,
    actual_cash_inflow     NUMERIC(16,2) NOT NULL DEFAULT 0,
    actual_cash_outflow    NUMERIC(16,2) NOT NULL DEFAULT 0,
    actual_roi_pct         NUMERIC(6,2),
    recorded_date          DATE NOT NULL DEFAULT CURRENT_DATE,
    recorded_by            UUID REFERENCES users(id),
    notes                  TEXT,
    created_at             TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_fin_actuals_baseline ON financial_actuals(baseline_id);

-- ============================================================================
-- 2) HUMAN RESOURCES DIMENSION
-- ============================================================================
CREATE TABLE hr_baselines (
    id                     UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    project_id             UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    period_label            VARCHAR(20) NOT NULL,
    period_start            DATE NOT NULL,
    period_end              DATE NOT NULL,
    planned_tasks_total      INTEGER NOT NULL,
    planned_resource_hours   NUMERIC(10,2) NOT NULL,
    planned_headcount        INTEGER NOT NULL,
    created_by               UUID REFERENCES users(id),
    created_at                TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (project_id, period_label)
);

CREATE TABLE hr_actuals (
    id                     UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    baseline_id            UUID NOT NULL REFERENCES hr_baselines(id) ON DELETE CASCADE,
    tasks_completed          INTEGER NOT NULL,
    resource_hours_used      NUMERIC(10,2) NOT NULL,
    headcount_actual          INTEGER NOT NULL,
    recorded_date              DATE NOT NULL DEFAULT CURRENT_DATE,
    recorded_by                UUID REFERENCES users(id),
    notes                       TEXT,
    created_at                  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_hr_actuals_baseline ON hr_actuals(baseline_id);

-- ============================================================================
-- 3) INFRASTRUCTURE & TECHNOLOGY DIMENSION
-- ============================================================================
CREATE TABLE infra_baselines (
    id                              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    project_id                      UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    period_label                     VARCHAR(20) NOT NULL,
    period_start                     DATE NOT NULL,
    period_end                       DATE NOT NULL,
    target_uptime_pct                 NUMERIC(5,2) NOT NULL DEFAULT 99.9,
    target_tech_readiness_score        NUMERIC(5,2) NOT NULL,   -- 0-100 scale
    target_digital_transformation_pct   NUMERIC(5,2) NOT NULL,  -- compliance target, 0-100
    created_by                          UUID REFERENCES users(id),
    created_at                           TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (project_id, period_label)
);

CREATE TABLE infra_actuals (
    id                              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    baseline_id                     UUID NOT NULL REFERENCES infra_baselines(id) ON DELETE CASCADE,
    actual_uptime_pct                 NUMERIC(5,2) NOT NULL,
    actual_tech_readiness_score        NUMERIC(5,2) NOT NULL,
    actual_digital_transformation_pct   NUMERIC(5,2) NOT NULL,
    incidents_count                      INTEGER NOT NULL DEFAULT 0,
    recorded_date                         DATE NOT NULL DEFAULT CURRENT_DATE,
    recorded_by                           UUID REFERENCES users(id),
    notes                                  TEXT,
    created_at                              TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_infra_actuals_baseline ON infra_actuals(baseline_id);

-- ============================================================================
-- 4) SCOPE & DELIVERABLES DIMENSION  (feeds Schedule Performance Index)
-- ============================================================================
CREATE TABLE scope_baselines (
    id                     UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    project_id             UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    period_label            VARCHAR(20) NOT NULL,
    period_start             DATE NOT NULL,
    period_end               DATE NOT NULL,
    planned_deliverables_count INTEGER NOT NULL,
    planned_value              NUMERIC(16,2) NOT NULL,   -- PV: budgeted cost of work scheduled
    planned_quality_score       NUMERIC(5,2) NOT NULL DEFAULT 100,  -- target quality index 0-100
    created_by                   UUID REFERENCES users(id),
    created_at                    TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (project_id, period_label)
);

CREATE TABLE scope_actuals (
    id                     UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    baseline_id            UUID NOT NULL REFERENCES scope_baselines(id) ON DELETE CASCADE,
    deliverables_completed  INTEGER NOT NULL,
    earned_value             NUMERIC(16,2) NOT NULL,   -- EV: budgeted cost of work actually performed
    quality_score             NUMERIC(5,2) NOT NULL,
    recorded_date              DATE NOT NULL DEFAULT CURRENT_DATE,
    recorded_by                UUID REFERENCES users(id),
    notes                       TEXT,
    created_at                   TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_scope_actuals_baseline ON scope_actuals(baseline_id);

-- ============================================================================
-- DERIVED VARIANCE VIEWS  (single source of truth for all % calculations)
-- ============================================================================

-- ---- Financial variance -----------------------------------------------------
CREATE VIEW v_financial_variance AS
SELECT
    fb.project_id,
    fb.id                                            AS baseline_id,
    fb.period_label,
    fb.planned_budget,
    fa.actual_cost,
    fa.id                                            AS actual_id,
    ROUND(((fa.actual_cost - fb.planned_budget) / NULLIF(fb.planned_budget,0)) * 100, 2)
                                                      AS budget_variance_pct,
    (fb.planned_cash_inflow - fb.planned_cash_outflow)  AS planned_net_cash_flow,
    (fa.actual_cash_inflow  - fa.actual_cash_outflow)   AS actual_net_cash_flow,
    fb.expected_roi_pct,
    fa.actual_roi_pct,
    ROUND(fa.actual_roi_pct - fb.expected_roi_pct, 2)   AS roi_variance_pct,
    fa.recorded_date
FROM financial_baselines fb
JOIN financial_actuals fa ON fa.baseline_id = fb.id;

-- ---- HR variance -------------------------------------------------------------
CREATE VIEW v_hr_variance AS
SELECT
    hb.project_id,
    hb.id AS baseline_id,
    hb.period_label,
    hb.planned_tasks_total,
    ha.tasks_completed,
    ROUND((ha.tasks_completed::NUMERIC / NULLIF(hb.planned_tasks_total,0)) * 100, 2)
                                                        AS task_completion_rate_pct,
    hb.planned_resource_hours,
    ha.resource_hours_used,
    ROUND((ha.resource_hours_used / NULLIF(hb.planned_resource_hours,0)) * 100, 2)
                                                        AS resource_utilization_pct,
    hb.planned_headcount,
    ha.headcount_actual,
    ha.recorded_date
FROM hr_baselines hb
JOIN hr_actuals ha ON ha.baseline_id = hb.id;

-- ---- Infrastructure variance ---------------------------------------------------
CREATE VIEW v_infra_variance AS
SELECT
    ib.project_id,
    ib.id AS baseline_id,
    ib.period_label,
    ib.target_uptime_pct,
    ia.actual_uptime_pct,
    ROUND(ia.actual_uptime_pct - ib.target_uptime_pct, 2)                  AS uptime_variance_pct,
    ib.target_tech_readiness_score,
    ia.actual_tech_readiness_score,
    ROUND(ia.actual_tech_readiness_score - ib.target_tech_readiness_score, 2)
                                                                            AS tech_readiness_variance,
    ib.target_digital_transformation_pct,
    ia.actual_digital_transformation_pct,
    ROUND(ia.actual_digital_transformation_pct - ib.target_digital_transformation_pct, 2)
                                                                            AS digital_transformation_variance_pct,
    ia.incidents_count,
    ia.recorded_date
FROM infra_baselines ib
JOIN infra_actuals ia ON ia.baseline_id = ib.id;

-- ---- Scope / Schedule Performance variance -------------------------------------
CREATE VIEW v_scope_variance AS
SELECT
    sb.project_id,
    sb.id AS baseline_id,
    sb.period_label,
    sb.planned_deliverables_count,
    sa.deliverables_completed,
    ROUND((sa.deliverables_completed::NUMERIC / NULLIF(sb.planned_deliverables_count,0)) * 100, 2)
                                                                 AS scope_progress_pct,
    sb.planned_value,
    sa.earned_value,
    ROUND(sa.earned_value / NULLIF(sb.planned_value,0), 3)      AS spi,              -- Schedule Performance Index
    CASE WHEN sa.earned_value / NULLIF(sb.planned_value,0) >= 1
         THEN 'ahead_or_on_schedule' ELSE 'behind_schedule' END AS schedule_status,
    sb.planned_quality_score,
    sa.quality_score,
    ROUND(sa.quality_score - sb.planned_quality_score, 2)       AS quality_variance,
    sa.recorded_date
FROM scope_baselines sb
JOIN scope_actuals sa ON sa.baseline_id = sb.id;

-- ---- Unified executive dashboard view (latest period per project) --------------
CREATE VIEW v_project_dashboard AS
SELECT
    p.id                        AS project_id,
    p.code,
    p.name,
    p.status,
    p.manager_id,
    fv.budget_variance_pct,
    fv.roi_variance_pct,
    hv.task_completion_rate_pct,
    hv.resource_utilization_pct,
    iv.uptime_variance_pct,
    iv.digital_transformation_variance_pct,
    sv.spi,
    sv.scope_progress_pct,
    sv.quality_variance
FROM projects p
LEFT JOIN LATERAL (
    SELECT * FROM v_financial_variance WHERE project_id = p.id ORDER BY recorded_date DESC LIMIT 1
) fv ON TRUE
LEFT JOIN LATERAL (
    SELECT * FROM v_hr_variance WHERE project_id = p.id ORDER BY recorded_date DESC LIMIT 1
) hv ON TRUE
LEFT JOIN LATERAL (
    SELECT * FROM v_infra_variance WHERE project_id = p.id ORDER BY recorded_date DESC LIMIT 1
) iv ON TRUE
LEFT JOIN LATERAL (
    SELECT * FROM v_scope_variance WHERE project_id = p.id ORDER BY recorded_date DESC LIMIT 1
) sv ON TRUE;

-- ============================================================================
-- updated_at auto-touch trigger (users, projects)
-- ============================================================================
CREATE OR REPLACE FUNCTION touch_updated_at() RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_users_touch BEFORE UPDATE ON users
    FOR EACH ROW EXECUTE FUNCTION touch_updated_at();
CREATE TRIGGER trg_projects_touch BEFORE UPDATE ON projects
    FOR EACH ROW EXECUTE FUNCTION touch_updated_at();

-- ============================================================================
-- SEED: default KPI thresholds
-- ============================================================================
INSERT INTO kpi_thresholds (dimension, metric_key, warning_threshold, critical_threshold, higher_is_better) VALUES
    ('financial',      'budget_variance_pct',        10, 20, FALSE),  -- % over budget
    ('financial',      'roi_variance_pct',             5, 15, TRUE),
    ('hr',              'task_completion_rate_pct',    10, 20, TRUE), -- % behind plan
    ('hr',              'resource_utilization_pct',    15, 30, FALSE),-- over-utilization risk
    ('infrastructure',  'uptime_variance_pct',          1,  3, TRUE),
    ('infrastructure',  'digital_transformation_variance_pct', 10, 25, TRUE),
    ('scope',            'spi',                       0.10, 0.20, TRUE), -- distance below 1.0
    ('scope',            'quality_variance',            5, 15, TRUE);
