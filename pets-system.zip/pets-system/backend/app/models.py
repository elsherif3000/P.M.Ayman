"""
SQLAlchemy models mirroring database/schema.sql.
Only columns needed by the API layer are declared; see schema.sql for the
authoritative DDL (constraints, indexes, views).
"""
import uuid
import enum
from sqlalchemy import (
    Column, String, Text, Date, DateTime, Numeric, Integer, Boolean,
    ForeignKey, Enum, UniqueConstraint, func
)
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship
from .database import Base


def uuid_pk():
    return Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)


class UserRole(str, enum.Enum):
    admin = "admin"
    executive = "executive"
    project_manager = "project_manager"
    evaluator = "evaluator"
    viewer = "viewer"


class ProjectStatus(str, enum.Enum):
    planning = "planning"
    active = "active"
    on_hold = "on_hold"
    completed = "completed"
    cancelled = "cancelled"


class ReportingPeriodType(str, enum.Enum):
    weekly = "weekly"
    monthly = "monthly"
    quarterly = "quarterly"
    milestone = "milestone"


class User(Base):
    __tablename__ = "users"
    id = uuid_pk()
    full_name = Column(String(150), nullable=False)
    email = Column(String(150), unique=True, nullable=False)
    password_hash = Column(String(255), nullable=False)
    role = Column(Enum(UserRole, name="user_role"), default=UserRole.viewer, nullable=False)
    department = Column(String(100))
    is_active = Column(Boolean, default=True, nullable=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())


class Project(Base):
    __tablename__ = "projects"
    id = uuid_pk()
    code = Column(String(30), unique=True, nullable=False)
    name = Column(String(200), nullable=False)
    description = Column(Text)
    status = Column(Enum(ProjectStatus, name="project_status"), default=ProjectStatus.planning, nullable=False)
    manager_id = Column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="SET NULL"))
    sponsor_id = Column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="SET NULL"))
    start_date = Column(Date, nullable=False)
    planned_end_date = Column(Date, nullable=False)
    actual_end_date = Column(Date)
    currency = Column(String(3), default="EGP", nullable=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    financial_baselines = relationship("FinancialBaseline", back_populates="project", cascade="all, delete-orphan")
    hr_baselines = relationship("HRBaseline", back_populates="project", cascade="all, delete-orphan")
    infra_baselines = relationship("InfraBaseline", back_populates="project", cascade="all, delete-orphan")
    scope_baselines = relationship("ScopeBaseline", back_populates="project", cascade="all, delete-orphan")


# ---------------------------------------------------------------------------
# 1) FINANCIAL
# ---------------------------------------------------------------------------
class FinancialBaseline(Base):
    __tablename__ = "financial_baselines"
    __table_args__ = (UniqueConstraint("project_id", "period_label"),)
    id = uuid_pk()
    project_id = Column(UUID(as_uuid=True), ForeignKey("projects.id", ondelete="CASCADE"), nullable=False)
    period_type = Column(
        Enum(ReportingPeriodType, name="reporting_period_type"),
        default=ReportingPeriodType.monthly, nullable=False,
    )
    period_label = Column(String(20), nullable=False)
    period_start = Column(Date, nullable=False)
    period_end = Column(Date, nullable=False)
    planned_budget = Column(Numeric(16, 2), nullable=False)
    planned_cash_inflow = Column(Numeric(16, 2), default=0)
    planned_cash_outflow = Column(Numeric(16, 2), default=0)
    expected_roi_pct = Column(Numeric(6, 2))
    created_by = Column(UUID(as_uuid=True), ForeignKey("users.id"))
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    project = relationship("Project", back_populates="financial_baselines")
    actuals = relationship("FinancialActual", back_populates="baseline", cascade="all, delete-orphan")


class FinancialActual(Base):
    __tablename__ = "financial_actuals"
    id = uuid_pk()
    baseline_id = Column(UUID(as_uuid=True), ForeignKey("financial_baselines.id", ondelete="CASCADE"), nullable=False)
    actual_cost = Column(Numeric(16, 2), nullable=False)
    actual_cash_inflow = Column(Numeric(16, 2), default=0)
    actual_cash_outflow = Column(Numeric(16, 2), default=0)
    actual_roi_pct = Column(Numeric(6, 2))
    recorded_date = Column(Date, server_default=func.current_date())
    recorded_by = Column(UUID(as_uuid=True), ForeignKey("users.id"))
    notes = Column(Text)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    baseline = relationship("FinancialBaseline", back_populates="actuals")


# ---------------------------------------------------------------------------
# 2) HUMAN RESOURCES
# ---------------------------------------------------------------------------
class HRBaseline(Base):
    __tablename__ = "hr_baselines"
    __table_args__ = (UniqueConstraint("project_id", "period_label"),)
    id = uuid_pk()
    project_id = Column(UUID(as_uuid=True), ForeignKey("projects.id", ondelete="CASCADE"), nullable=False)
    period_label = Column(String(20), nullable=False)
    period_start = Column(Date, nullable=False)
    period_end = Column(Date, nullable=False)
    planned_tasks_total = Column(Integer, nullable=False)
    planned_resource_hours = Column(Numeric(10, 2), nullable=False)
    planned_headcount = Column(Integer, nullable=False)
    created_by = Column(UUID(as_uuid=True), ForeignKey("users.id"))
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    project = relationship("Project", back_populates="hr_baselines")
    actuals = relationship("HRActual", back_populates="baseline", cascade="all, delete-orphan")


class HRActual(Base):
    __tablename__ = "hr_actuals"
    id = uuid_pk()
    baseline_id = Column(UUID(as_uuid=True), ForeignKey("hr_baselines.id", ondelete="CASCADE"), nullable=False)
    tasks_completed = Column(Integer, nullable=False)
    resource_hours_used = Column(Numeric(10, 2), nullable=False)
    headcount_actual = Column(Integer, nullable=False)
    recorded_date = Column(Date, server_default=func.current_date())
    recorded_by = Column(UUID(as_uuid=True), ForeignKey("users.id"))
    notes = Column(Text)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    baseline = relationship("HRBaseline", back_populates="actuals")


# ---------------------------------------------------------------------------
# 3) INFRASTRUCTURE & TECHNOLOGY
# ---------------------------------------------------------------------------
class InfraBaseline(Base):
    __tablename__ = "infra_baselines"
    __table_args__ = (UniqueConstraint("project_id", "period_label"),)
    id = uuid_pk()
    project_id = Column(UUID(as_uuid=True), ForeignKey("projects.id", ondelete="CASCADE"), nullable=False)
    period_label = Column(String(20), nullable=False)
    period_start = Column(Date, nullable=False)
    period_end = Column(Date, nullable=False)
    target_uptime_pct = Column(Numeric(5, 2), default=99.9)
    target_tech_readiness_score = Column(Numeric(5, 2), nullable=False)
    target_digital_transformation_pct = Column(Numeric(5, 2), nullable=False)
    created_by = Column(UUID(as_uuid=True), ForeignKey("users.id"))
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    project = relationship("Project", back_populates="infra_baselines")
    actuals = relationship("InfraActual", back_populates="baseline", cascade="all, delete-orphan")


class InfraActual(Base):
    __tablename__ = "infra_actuals"
    id = uuid_pk()
    baseline_id = Column(UUID(as_uuid=True), ForeignKey("infra_baselines.id", ondelete="CASCADE"), nullable=False)
    actual_uptime_pct = Column(Numeric(5, 2), nullable=False)
    actual_tech_readiness_score = Column(Numeric(5, 2), nullable=False)
    actual_digital_transformation_pct = Column(Numeric(5, 2), nullable=False)
    incidents_count = Column(Integer, default=0)
    recorded_date = Column(Date, server_default=func.current_date())
    recorded_by = Column(UUID(as_uuid=True), ForeignKey("users.id"))
    notes = Column(Text)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    baseline = relationship("InfraBaseline", back_populates="actuals")


# ---------------------------------------------------------------------------
# 4) SCOPE & DELIVERABLES
# ---------------------------------------------------------------------------
class ScopeBaseline(Base):
    __tablename__ = "scope_baselines"
    __table_args__ = (UniqueConstraint("project_id", "period_label"),)
    id = uuid_pk()
    project_id = Column(UUID(as_uuid=True), ForeignKey("projects.id", ondelete="CASCADE"), nullable=False)
    period_label = Column(String(20), nullable=False)
    period_start = Column(Date, nullable=False)
    period_end = Column(Date, nullable=False)
    planned_deliverables_count = Column(Integer, nullable=False)
    planned_value = Column(Numeric(16, 2), nullable=False)
    planned_quality_score = Column(Numeric(5, 2), default=100)
    created_by = Column(UUID(as_uuid=True), ForeignKey("users.id"))
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    project = relationship("Project", back_populates="scope_baselines")
    actuals = relationship("ScopeActual", back_populates="baseline", cascade="all, delete-orphan")


class ScopeActual(Base):
    __tablename__ = "scope_actuals"
    id = uuid_pk()
    baseline_id = Column(UUID(as_uuid=True), ForeignKey("scope_baselines.id", ondelete="CASCADE"), nullable=False)
    deliverables_completed = Column(Integer, nullable=False)
    earned_value = Column(Numeric(16, 2), nullable=False)
    quality_score = Column(Numeric(5, 2), nullable=False)
    recorded_date = Column(Date, server_default=func.current_date())
    recorded_by = Column(UUID(as_uuid=True), ForeignKey("users.id"))
    notes = Column(Text)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    baseline = relationship("ScopeBaseline", back_populates="actuals")


class KPIThreshold(Base):
    __tablename__ = "kpi_thresholds"
    id = uuid_pk()
    dimension = Column(String(20), nullable=False)
    metric_key = Column(String(50), nullable=False)
    warning_threshold = Column(Numeric(6, 2), nullable=False)
    critical_threshold = Column(Numeric(6, 2), nullable=False)
    higher_is_better = Column(Boolean, default=True)
