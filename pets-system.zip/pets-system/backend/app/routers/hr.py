import uuid
from typing import List
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select, text
from sqlalchemy.ext.asyncio import AsyncSession

from ..database import get_db
from ..models import HRBaseline, HRActual, Project
from ..schemas.hr import HRBaselineCreate, HRBaselineOut, HRActualCreate, HRActualOut, HRVarianceOut
from ..status_utils import resolve_status

router = APIRouter(prefix="/api/v1/projects/{project_id}/hr", tags=["HR Dimension"])


async def _get_project_or_404(db: AsyncSession, project_id: uuid.UUID) -> Project:
    project = await db.get(Project, project_id)
    if not project:
        raise HTTPException(404, "Project not found")
    return project


@router.post("/baselines", response_model=HRBaselineOut, status_code=201)
async def create_hr_baseline(project_id: uuid.UUID, payload: HRBaselineCreate, db: AsyncSession = Depends(get_db)):
    await _get_project_or_404(db, project_id)
    baseline = HRBaseline(project_id=project_id, **payload.model_dump())
    db.add(baseline)
    await db.commit()
    await db.refresh(baseline)
    return baseline


@router.get("/baselines", response_model=List[HRBaselineOut])
async def list_hr_baselines(project_id: uuid.UUID, db: AsyncSession = Depends(get_db)):
    await _get_project_or_404(db, project_id)
    result = await db.execute(select(HRBaseline).where(HRBaseline.project_id == project_id))
    return result.scalars().all()


@router.post("/baselines/{baseline_id}/actuals", response_model=HRActualOut, status_code=201)
async def record_hr_actual(
    project_id: uuid.UUID, baseline_id: uuid.UUID, payload: HRActualCreate, db: AsyncSession = Depends(get_db)
):
    baseline = await db.get(HRBaseline, baseline_id)
    if not baseline or baseline.project_id != project_id:
        raise HTTPException(404, "Baseline not found for this project")
    actual = HRActual(baseline_id=baseline_id, **payload.model_dump(exclude_none=True))
    db.add(actual)
    await db.commit()
    await db.refresh(actual)
    return actual


@router.get("/variance", response_model=List[HRVarianceOut])
async def get_hr_variance(project_id: uuid.UUID, db: AsyncSession = Depends(get_db)):
    await _get_project_or_404(db, project_id)
    rows = (await db.execute(
        text("SELECT * FROM v_hr_variance WHERE project_id = :pid ORDER BY recorded_date"),
        {"pid": str(project_id)},
    )).mappings().all()

    out = []
    for row in rows:
        data = dict(row)
        # Two metrics feed status here: completion behind plan, and over-utilization risk
        completion_status = await resolve_status(db, "task_completion_rate_pct",
                                                   (data.get("task_completion_rate_pct") or 0) - 100)
        util_status = await resolve_status(db, "resource_utilization_pct",
                                            (data.get("resource_utilization_pct") or 0) - 100)
        rank = {"on_track": 0, "warning": 1, "critical": 2}
        data["status"] = max([completion_status, util_status], key=lambda s: rank[s])
        out.append(data)
    return out
