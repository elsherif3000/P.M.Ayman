import uuid
from datetime import date, datetime
from decimal import Decimal
from typing import Optional
from pydantic import BaseModel, Field, ConfigDict


class FinancialBaselineCreate(BaseModel):
    period_label: str = Field(..., max_length=20, examples=["2026-08"])
    period_type: str = Field(default="monthly")
    period_start: date
    period_end: date
    planned_budget: Decimal = Field(..., gt=0)
    planned_cash_inflow: Decimal = Decimal("0")
    planned_cash_outflow: Decimal = Decimal("0")
    expected_roi_pct: Optional[Decimal] = None


class FinancialBaselineOut(FinancialBaselineCreate):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    project_id: uuid.UUID
    created_at: datetime


class FinancialActualCreate(BaseModel):
    actual_cost: Decimal = Field(..., ge=0)
    actual_cash_inflow: Decimal = Decimal("0")
    actual_cash_outflow: Decimal = Decimal("0")
    actual_roi_pct: Optional[Decimal] = None
    recorded_date: Optional[date] = None
    notes: Optional[str] = None


class FinancialActualOut(FinancialActualCreate):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    baseline_id: uuid.UUID
    created_at: datetime


class FinancialVarianceOut(BaseModel):
    """Mirrors the v_financial_variance SQL view — always server-computed."""
    project_id: uuid.UUID
    baseline_id: uuid.UUID
    period_label: str
    planned_budget: Decimal
    actual_cost: Decimal
    budget_variance_pct: Decimal
    planned_net_cash_flow: Decimal
    actual_net_cash_flow: Decimal
    expected_roi_pct: Optional[Decimal] = None
    actual_roi_pct: Optional[Decimal] = None
    roi_variance_pct: Optional[Decimal] = None
    status: str  # on_track | warning | critical
