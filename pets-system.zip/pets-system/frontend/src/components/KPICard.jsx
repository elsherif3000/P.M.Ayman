const TREND_COLOR = {
  up: "text-status-onTrack",
  down: "text-status-critical",
  flat: "text-mist",
};

/**
 * A single dimension's fleet-wide summary: how many projects are in each
 * status bucket, plus one headline metric (e.g. avg budget variance).
 */
export default function KPICard({ label, eyebrow, value, unit, counts, trend }) {
  const total = (counts?.on_track ?? 0) + (counts?.warning ?? 0) + (counts?.critical ?? 0);

  return (
    <div className="rounded-xl border border-ink-700 bg-ink-900 p-5 flex flex-col gap-4">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-[11px] font-mono uppercase tracking-wider text-mist">{eyebrow}</p>
          <h3 className="font-display text-sm text-ivory mt-0.5">{label}</h3>
        </div>
        {trend && (
          <span className={`text-xs font-mono ${TREND_COLOR[trend.direction]}`}>
            {trend.direction === "up" ? "▲" : trend.direction === "down" ? "▼" : "—"} {trend.value}
          </span>
        )}
      </div>

      <div className="flex items-baseline gap-1">
        <span className="font-mono text-3xl text-ivory tabular-nums">{value}</span>
        {unit && <span className="text-sm text-mist">{unit}</span>}
      </div>

      {counts && total > 0 && (
        <div>
          <div className="flex h-1.5 w-full overflow-hidden rounded-full bg-ink-700">
            <div className="bg-status-onTrack" style={{ width: `${(counts.on_track / total) * 100}%` }} />
            <div className="bg-status-warning" style={{ width: `${(counts.warning / total) * 100}%` }} />
            <div className="bg-status-critical" style={{ width: `${(counts.critical / total) * 100}%` }} />
          </div>
          <div className="mt-2 flex justify-between text-[11px] font-mono text-mist">
            <span>{counts.on_track} on track</span>
            <span>{counts.warning} warning</span>
            <span>{counts.critical} critical</span>
          </div>
        </div>
      )}
    </div>
  );
}
